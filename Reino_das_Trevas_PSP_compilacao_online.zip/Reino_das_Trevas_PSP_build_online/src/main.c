
#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspgu.h>
#include <pspctrl.h>
#include <pspdebug.h>
#include <math.h>
#include <string.h>
#include <stdio.h>

PSP_MODULE_INFO("Reino das Trevas", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER | THREAD_ATTR_VFPU);

#define W 480
#define H 272
#define BUF_WIDTH 512
#define LIST_SIZE (256 * 1024)
#define MAX_CRYSTALS 8
#define MAX_ENEMIES 5

static unsigned int __attribute__((aligned(16))) list[LIST_SIZE / 4];
static unsigned int __attribute__((aligned(16))) fb0[BUF_WIDTH * H];
static unsigned int __attribute__((aligned(16))) fb1[BUF_WIDTH * H];
static int back = 0;

typedef struct { float x, y; int alive; } Item;
typedef struct { float x, y, hp; int alive; } Enemy;

static Item crystals[MAX_CRYSTALS];
static Enemy enemies[MAX_ENEMIES];
static float px = 240.0f, py = 210.0f;
static int hp = 3, score = 0, has_sword = 0, boss_hp = 12;
static float day_clock = 0.0f;
static int attack_flash = 0;

static unsigned int rgba(unsigned char r, unsigned char g, unsigned char b, unsigned char a) {
    return ((unsigned int)a << 24) | ((unsigned int)b << 16) | ((unsigned int)g << 8) | r;
}

static void setup_gu(void) {
    sceGuInit();
    sceGuStart(GU_DIRECT, list);
    sceGuDrawBuffer(GU_PSM_8888, (void*)0, BUF_WIDTH);
    sceGuDispBuffer(W, H, (void*)0x88000, BUF_WIDTH);
    sceGuDepthBuffer((void*)0x110000, BUF_WIDTH);
    sceGuOffset(2048 - W/2, 2048 - H/2);
    sceGuViewport(2048, 2048, W, H);
    sceGuDepthRange(65535, 0);
    sceGuScissor(0, 0, W, H);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuDisable(GU_DEPTH_TEST);
    sceGuDisable(GU_CULL_FACE);
    sceGuShadeModel(GU_FLAT);
    sceGuFinish();
    sceGuSync(0, 0);
    sceGuDisplay(GU_TRUE);
}

typedef struct { short x, y, z; unsigned int color; } Vertex;
static void rect(float x, float y, float w, float h, unsigned int color) {
    Vertex *v = (Vertex*)sceGuGetMemory(2 * sizeof(Vertex));
    v[0].x = (short)x;     v[0].y = (short)y;     v[0].z = 0; v[0].color = color;
    v[1].x = (short)(x+w); v[1].y = (short)(y+h); v[1].z = 0; v[1].color = color;
    sceGuDrawArray(GU_SPRITES, GU_COLOR_8888 | GU_VERTEX_16BIT | GU_TRANSFORM_2D, 2, 0, v);
}
static void circle(float cx, float cy, float r, unsigned int color) {
    Vertex *v = (Vertex*)sceGuGetMemory(34 * sizeof(Vertex));
    v[0].x=(short)cx; v[0].y=(short)cy; v[0].z=0; v[0].color=color;
    for (int i=0;i<=32;i++) {
        float a = (float)i * 6.2831853f / 32.0f;
        v[i+1].x=(short)(cx+cosf(a)*r);
        v[i+1].y=(short)(cy+sinf(a)*r);
        v[i+1].z=0; v[i+1].color=color;
    }
    sceGuDrawArray(GU_TRIANGLE_FAN, GU_COLOR_8888 | GU_VERTEX_16BIT | GU_TRANSFORM_2D, 34, 0, v);
}
static void line(float x1,float y1,float x2,float y2,unsigned int color) {
    Vertex *v=(Vertex*)sceGuGetMemory(2*sizeof(Vertex));
    v[0].x=(short)x1;v[0].y=(short)y1;v[0].z=0;v[0].color=color;
    v[1].x=(short)x2;v[1].y=(short)y2;v[1].z=0;v[1].color=color;
    sceGuDrawArray(GU_LINES,GU_COLOR_8888|GU_VERTEX_16BIT|GU_TRANSFORM_2D,2,0,v);
}
static void draw_scene(void) {
    int night = ((int)(day_clock / 6.0f) % 2) == 0;
    unsigned int sky = night ? rgba(5,7,25,255) : rgba(91,145,190,255);
    unsigned int ground = night ? rgba(20,25,43,255) : rgba(54,65,67,255);
    sceGuStart(GU_DIRECT, list);
    sceGuClearColor(sky);
    sceGuClear(GU_COLOR_BUFFER_BIT);
    rect(0, 80, W, H-80, ground);
    /* Rua e ruínas em perspectiva simplificada */
    rect(188, 80, 104, 192, night ? rgba(37,42,72,255) : rgba(91,89,83,255));
    for (int i=0;i<7;i++) {
        int y = 90 + i*29;
        rect(192,y,96,2,rgba(15,17,29,255));
    }
    /* casas/ruínas laterais */
    for (int i=0;i<4;i++) {
        int y=94+i*43;
        rect(30,y,55,32,rgba(48,43,62,255));
        rect(395,y+7,53,28,rgba(47,42,59,255));
        line(30,y,57,y-13,rgba(103,79,91,255));
        line(57,y-13,85,y,rgba(103,79,91,255));
        line(395,y+7,421,y-7,rgba(103,79,91,255));
        line(421,y-7,448,y+7,rgba(103,79,91,255));
    }
    /* castelo distante */
    rect(201,36,78,45,rgba(43,42,72,255));
    rect(211,23,15,25,rgba(57,55,87,255));
    rect(254,20,15,28,rgba(57,55,87,255));
    rect(234,13,13,34,rgba(64,61,97,255));
    rect(219,51,7,10,rgba(255,209,99,255));
    rect(254,51,7,10,rgba(255,209,99,255));
    /* cristais */
    for(int i=0;i<MAX_CRYSTALS;i++) if(crystals[i].alive) {
        circle(crystals[i].x,crystals[i].y,8,rgba(24,120,166,255));
        circle(crystals[i].x,crystals[i].y,4,rgba(130,250,255,255));
    }
    /* inimigos */
    for(int i=0;i<MAX_ENEMIES;i++) if(enemies[i].alive) {
        circle(enemies[i].x,enemies[i].y,10,rgba(30,104,66,255));
        circle(enemies[i].x-3,enemies[i].y-2,2,rgba(255,30,70,255));
        circle(enemies[i].x+3,enemies[i].y-2,2,rgba(255,30,70,255));
        rect(enemies[i].x-9,enemies[i].y-16,18,3,rgba(80,15,25,255));
        rect(enemies[i].x-9,enemies[i].y-16,18*enemies[i].hp/4.0f,3,rgba(55,240,110,255));
    }
    /* guardião */
    if(boss_hp>0) {
        circle(240,111,15,rgba(20,94,58,255));
        circle(234,108,3,rgba(255,20,65,255));
        circle(246,108,3,rgba(255,20,65,255));
        rect(196,88,88,5,rgba(50,10,22,255));
        rect(196,88,88*boss_hp/12.0f,5,rgba(255,48,85,255));
    }
    /* jogador e espada */
    circle(px,py,9,rgba(54,49,113,255));
    circle(px,py-5,5,rgba(178,151,126,255));
    if(has_sword) line(px+7,py,px+18,py-10,rgba(224,235,255,255));
    if(attack_flash>0) {
        circle(px,py-12,24,rgba(110,220,255,100));
        attack_flash--;
    }
    /* HUD em barras para evitar dependência de fontes externas */
    rect(8,8,138,33,rgba(5,7,23,230));
    rect(15,16,50,5,rgba(80,12,30,255));
    rect(15,16,50*hp/3.0f,5,rgba(255,55,85,255));
    for(int i=0;i<8;i++) rect(15+i*13,27,9,4,i<score?rgba(90,240,255,255):rgba(52,61,80,255));
    rect(350,8,122,9,rgba(5,7,23,230));
    rect(354,11,114,3,night?rgba(130,150,255,255):rgba(255,213,91,255));
    sceGuFinish();
    sceGuSync(0,0);
    sceDisplayWaitVblankStart();
    sceGuSwapBuffers();
}
static void reset_game(void) {
    px=240; py=210; hp=3; score=0; has_sword=0; boss_hp=12; day_clock=0;
    for(int i=0;i<MAX_CRYSTALS;i++) {
        crystals[i].x=70+(i*47)%340;
        crystals[i].y=105+(i*31)%125;
        crystals[i].alive=1;
    }
    for(int i=0;i<MAX_ENEMIES;i++) {
        enemies[i].x=80+(i*73)%320;
        enemies[i].y=125+(i*23)%105;
        enemies[i].hp=(i%3==0)?2:4;
        enemies[i].alive=1;
    }
}
static void update_game(void) {
    SceCtrlData pad;
    sceCtrlPeekBufferPositive(&pad,1);
    float speed=2.1f;
    if(pad.Buttons & PSP_CTRL_UP) py-=speed;
    if(pad.Buttons & PSP_CTRL_DOWN) py+=speed;
    if(pad.Buttons & PSP_CTRL_LEFT) px-=speed;
    if(pad.Buttons & PSP_CTRL_RIGHT) px+=speed;
    if(pad.Ly < 90) py-=speed;
    if(pad.Ly > 165) py+=speed;
    if(pad.Lx < 90) px-=speed;
    if(pad.Lx > 165) px+=speed;
    if(px<14)px=14;if(px>466)px=466;if(py<94)py=94;if(py>260)py=260;
    day_clock+=0.025f;
    for(int i=0;i<MAX_CRYSTALS;i++) if(crystals[i].alive) {
        float dx=px-crystals[i].x,dy=py-crystals[i].y;
        if(dx*dx+dy*dy<18*18){crystals[i].alive=0;score++;if(score>=8)boss_hp=0;}
    }
    for(int i=0;i<MAX_ENEMIES;i++) if(enemies[i].alive) {
        float dx=px-enemies[i].x,dy=py-enemies[i].y;
        float d=sqrtf(dx*dx+dy*dy);
        if(d>13){enemies[i].x+=dx/d*.22f;enemies[i].y+=dy/d*.22f;}
        if(d<15 && (pad.Buttons & PSP_CTRL_CROSS) && has_sword) {
            enemies[i].hp-=1;
            if(enemies[i].hp<=0){enemies[i].alive=0;score++;}
        }
        if(d<12 && (pad.Buttons & PSP_CTRL_CIRCLE)) {
            enemies[i].x += dx>0?22:-22; enemies[i].y += dy>0?14:-14;
        }
        if(d<10 && hp>0) { /* dano com pequeno recuo */ hp--; enemies[i].x-=dx*.5f; enemies[i].y-=dy*.5f; }
    }
    if(pad.Buttons & PSP_CTRL_TRIANGLE) has_sword=1; /* protótipo: recolhe espada */
    if((pad.Buttons & PSP_CTRL_CROSS) && boss_hp>0 && has_sword) {
        float dx=px-240,dy=py-111;
        if(dx*dx+dy*dy<48*48) { boss_hp--; attack_flash=3; }
    }
}
int main(void) {
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
    setup_gu();
    reset_game();
    pspDebugScreenInit();
    while(1) {
        update_game();
        draw_scene();
        if(hp<=0 || score>=8 || boss_hp<=0) {
            pspDebugScreenSetBackColor(0x000000);
            pspDebugScreenSetTextColor(0xffffffff);
            pspDebugScreenClear();
            pspDebugScreenPrintf("REINO DAS TREVAS - PROTOTIPO PSP\n\n");
            if(hp<=0) pspDebugScreenPrintf("Voce foi derrotado!\n");
            else pspDebugScreenPrintf("Cristais coletados: %d/8\n",score);
            pspDebugScreenPrintf("\nSTART: reiniciar | SELECT: sair\n");
            while(1) {
                SceCtrlData pad; sceCtrlPeekBufferPositive(&pad,1);
                if(pad.Buttons & PSP_CTRL_START) { reset_game(); break; }
                if(pad.Buttons & PSP_CTRL_SELECT) sceKernelExitGame();
                sceDisplayWaitVblankStart();
            }
        }
        SceCtrlData pad; sceCtrlPeekBufferPositive(&pad,1);
        if(pad.Buttons & PSP_CTRL_SELECT) sceKernelExitGame();
    }
    sceKernelExitGame();
    return 0;
}
