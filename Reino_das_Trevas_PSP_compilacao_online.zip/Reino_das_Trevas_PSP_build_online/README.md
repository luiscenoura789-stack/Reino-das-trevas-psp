# Reino das Trevas — protótipo simples para PPSSPP

Este pacote contém o código-fonte e um workflow do GitHub Actions para tentar compilar o homebrew usando a imagem oficial PSPDEV. O projeto **ainda não inclui um EBOOT.PBP pronto nem foi testado no PPSSPP**.

## Como tentar compilar usando somente o celular

1. Entre ou crie uma conta no GitHub.
2. No navegador, crie um repositório novo chamado `reino-das-trevas-psp`.
3. Envie os arquivos e pastas deste ZIP para a raiz do repositório, mantendo a estrutura, inclusive `.github/workflows/compilar-psp.yml`.
4. Abra a aba **Actions** do repositório. Se aparecer um aviso para habilitar Actions, habilite-o.
5. Abra o workflow **Compilar Reino das Trevas PSP** e toque em **Run workflow** (ou envie os arquivos para `main` para disparar automaticamente).
6. Espere a execução terminar. Se ficar verde, abra a execução e baixe o artifact `ReinoDasTrevas-EBOOT-PBP`.
7. Extraia o artifact ZIP e coloque `EBOOT.PBP` em `PSP/GAME/ReinoDasTrevas/` no armazenamento que o PPSSPP consegue acessar.

## Limitações

- O build pode falhar e exigir correções; não foi possível testar o compilador nesta sessão.
- Mesmo se compilar, é um protótipo gráfico simples, não o jogo HTML 3D original.
- Não baixe nem execute arquivos de repositórios desconhecidos. Este workflow usa a imagem PSPDEV e ações oficiais do GitHub.
